# Task 3
# By: Daniel Gallagher
import pandas as pd

# Read data from an Excel sheet
df = pd.read_excel('list for task 3.xlsx')

# Find all members who have not paid 
# their dues for the month of may

# Find their email address and send them personalized 
# reminders
